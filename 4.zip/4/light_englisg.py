import json
import os
from tkinter import *
from tkinter import messagebox, ttk
from random import choice, shuffle

class EnglishWords:
    def __init__(self):
        self.users_file = "users_words.json"
        self.data_file = "words_data.json"
        self.current_user = None
        self.initialize_files()

    def initialize_files(self):
        """Инициализирует файлы с проверкой их валидности"""
        for file, default in [
            (self.users_file, {"users": []}),
            (self.data_file, {"categories": {}})
        ]:
            if not os.path.exists(file):
                with open(file, 'w') as f:
                    json.dump(default, f, indent=4)
            else:
                try:
                    with open(file, 'r') as f:
                        json.load(f)
                except json.JSONDecodeError:
                    with open(file, 'w') as f:
                        json.dump(default, f, indent=4)

    def register_user(self, login, password):
        """Регистрирует нового пользователя"""
        try:
            with open(self.users_file, 'r+') as f:
                data = json.load(f)
                
                if any(user["login"] == login for user in data["users"]):
                    return False
                    
                data["users"].append({"login": login, "password": password})
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
                
            self.init_user_data(login)
            return True
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось зарегистрироваться: {str(e)}")
            return False

    def init_user_data(self, login):
        """Инициализирует данные пользователя"""
        try:
            with open(self.data_file, 'r+') as f:
                data = json.load(f)
                if "categories" not in data:
                    data["categories"] = {}
                
                if login not in data["categories"]:
                    data["categories"][login] = {
                        "Основные": {"apple": "яблоко", "book": "книга", "house": "дом"},
                        "Глаголы": {"run": "бежать", "read": "читать", "write": "писать"},
                        "Прилагательные": {"happy": "счастливый", "big": "большой", "small": "маленький"}
                    }
                    f.seek(0)
                    json.dump(data, f, indent=4)
                    f.truncate()
        except Exception as e:
            print(f"Ошибка инициализации данных: {str(e)}")

    def login_user(self, login, password):
        """Аутентификация пользователя"""
        try:
            with open(self.users_file, 'r') as f:
                data = json.load(f)
                for user in data["users"]:
                    if user["login"] == login and user["password"] == password:
                        self.current_user = login
                        return True
            return False
        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка входа: {str(e)}")
            return False

    def get_user_categories(self):
        """Получает категории пользователя"""
        try:
            with open(self.data_file, 'r') as f:
                data = json.load(f)
                return data["categories"].get(self.current_user, {})
        except Exception:
            return {}

    def add_category(self, category_name):
        """Добавляет новую категорию"""
        try:
            with open(self.data_file, 'r+') as f:
                data = json.load(f)
                if category_name not in data["categories"][self.current_user]:
                    data["categories"][self.current_user][category_name] = {}
                    f.seek(0)
                    json.dump(data, f, indent=4)
                    f.truncate()
                    return True
                return False
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось добавить категорию: {str(e)}")
            return False

    def add_word(self, category, english, russian):
        """Добавляет слово в категорию"""
        try:
            with open(self.data_file, 'r+') as f:
                data = json.load(f)
                if category in data["categories"][self.current_user]:
                    data["categories"][self.current_user][category][english] = russian
                    f.seek(0)
                    json.dump(data, f, indent=4)
                    f.truncate()
                    return True
                return False
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось добавить слово: {str(e)}")
            return False

    def get_random_word(self, category):
        """Получает случайное слово из категории"""
        try:
            with open(self.data_file, 'r') as f:
                data = json.load(f)
                words = data["categories"][self.current_user].get(category, {})
                if words:
                    english = choice(list(words.keys()))
                    return english, words[english]
                return None, None
        except Exception:
            return None, None

    def get_words_count(self):
        """Получает статистику по словам"""
        try:
            with open(self.data_file, 'r') as f:
                data = json.load(f)
                categories = data["categories"].get(self.current_user, {})
                total = sum(len(words) for words in categories.values())
                return {
                    "total": total,
                    "categories": {cat: len(words) for cat, words in categories.items()}
                }
        except Exception:
            return {"total": 0, "categories": {}}

    def get_all_words(self, category):
        """Получает все слова из категории"""
        try:
            with open(self.data_file, 'r') as f:
                data = json.load(f)
                return data["categories"][self.current_user].get(category, {})
        except Exception:
            return {}

class AuthWindow:
    def __init__(self, root, app):
        self.root = root
        self.app = app
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Light English • Авторизация")
        self.root.geometry("400x600")
        self.root.resizable(False, False)
        self.root.configure(bg="#F3E5F5")
        center_window(self.root, 400, 600)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#F3E5F5", padx=30, pady=40)
        main_frame.pack(expand=True, fill=BOTH)
        
        # Логотип
        logo_frame = Frame(main_frame, bg="#F3E5F5")
        logo_frame.pack(pady=(0, 30))
        
        Label(logo_frame, text="📚", font=("Arial", 48), bg="#F3E5F5", fg="#7B1FA2").pack()
        Label(logo_frame, text="Light English", font=("Arial", 24, "bold"), bg="#F3E5F5", fg="#7B1FA2").pack(pady=(10, 0))
        Label(logo_frame, text="Изучение английских слов", font=("Arial", 10), bg="#F3E5F5", fg="#AB47BC").pack()
        
        # Форма входа
        form_frame = Frame(main_frame, bg="#F3E5F5")
        form_frame.pack(fill=X, pady=(20, 0))
        
        Label(form_frame, text="Логин", font=("Arial", 10), bg="#F3E5F5", fg="#7B1FA2", anchor="w").pack(fill=X, pady=(0, 5))
        self.login_entry = Entry(form_frame, font=("Arial", 12), bg="#E1BEE7", fg="#4A148C", insertbackground="#4A148C", relief=FLAT)
        self.login_entry.pack(fill=X, ipady=5, padx=5, pady=5)
        
        Label(form_frame, text="Пароль", font=("Arial", 10), bg="#F3E5F5", fg="#7B1FA2", anchor="w").pack(fill=X, pady=(15, 5))
        self.password_entry = Entry(form_frame, show="•", font=("Arial", 12), bg="#E1BEE7", fg="#4A148C", insertbackground="#4A148C", relief=FLAT)
        self.password_entry.pack(fill=X, ipady=5, padx=5, pady=5)
        
        # Кнопки
        button_frame = Frame(main_frame, bg="#F3E5F5")
        button_frame.pack(fill=X, pady=(30, 0))
        
        Button(button_frame, text="Войти", command=self.login, 
              bg="#7B1FA2", fg="white", font=("Arial", 12, "bold"), 
              relief=FLAT, padx=20, pady=10).pack(fill=X, pady=(0, 10))
        
        Button(button_frame, text="Создать аккаунт", command=self.open_register,
              bg="#AB47BC", fg="white", font=("Arial", 12), 
              relief=FLAT, padx=20, pady=10).pack(fill=X)
        
        # Подвал
        Label(main_frame, text="© 2025 Light English | Учите английский с удовольствием", 
             font=("Arial", 8), bg="#F3E5F5", fg="#AB47BC").pack(pady=(30, 0))

    def login(self):
        login = self.login_entry.get()
        password = self.password_entry.get()
        
        if not login or not password:
            messagebox.showwarning("Ошибка", "Введите логин и пароль")
            return
            
        if self.app.login_user(login, password):
            self.root.destroy()
            MainWindow(Tk(), self.app)
        else:
            messagebox.showerror("Ошибка", "Неверный логин или пароль")

    def open_register(self):
        register_window = Toplevel(self.root)
        RegisterWindow(register_window, self.app)

class RegisterWindow:
    def __init__(self, root, app):
        self.root = root
        self.app = app
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Регистрация")
        self.root.geometry("400x400")
        self.root.configure(bg="#F3E5F5")
        center_window(self.root, 400, 400)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#F3E5F5", padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text="Создать аккаунт", font=("Arial", 20, "bold"), 
             bg="#F3E5F5", fg="#7B1FA2").pack(pady=20)
        
        # Поля формы
        form_frame = Frame(main_frame, bg="#F3E5F5")
        form_frame.pack(fill=X, pady=10)
        
        Label(form_frame, text="Логин:", bg="#F3E5F5", fg="#7B1FA2").pack(anchor="w")
        self.login_entry = Entry(form_frame, font=("Arial", 12), bg="#E1BEE7", fg="#4A148C")
        self.login_entry.pack(fill=X, pady=5)
        
        Label(form_frame, text="Пароль:", bg="#F3E5F5", fg="#7B1FA2").pack(anchor="w")
        self.password_entry = Entry(form_frame, show="•", font=("Arial", 12), bg="#E1BEE7", fg="#4A148C")
        self.password_entry.pack(fill=X, pady=5)
        
        # Кнопки
        Button(main_frame, text="Зарегистрироваться", command=self.register,
              bg="#7B1FA2", fg="white", font=("Arial", 12), 
              padx=20, pady=10).pack(pady=20)
        
        Button(main_frame, text="Отмена", command=self.root.destroy,
              bg="#AB47BC", fg="white", font=("Arial", 10), 
              padx=15, pady=5).pack()

    def register(self):
        login = self.login_entry.get()
        password = self.password_entry.get()
        
        if not login or not password:
            messagebox.showwarning("Ошибка", "Заполните все поля")
            return
            
        if self.app.register_user(login, password):
            messagebox.showinfo("Успех", "Регистрация завершена!")
            self.root.destroy()
        else:
            messagebox.showerror("Ошибка", "Логин уже занят")

class MainWindow:
    def __init__(self, root, app):
        self.root = root
        self.app = app
        self.current_category = None
        self.current_word = None
        self.current_translation = None
        self.word_list = []
        self.current_index = 0
        self.setup_window()
        self.create_widgets()
        self.update_stats()
        
    def setup_window(self):
        self.root.title("Light English")
        self.root.geometry("900x650")
        self.root.configure(bg="#F3E5F5")
        center_window(self.root, 900, 650)
        
    def create_widgets(self):
        # Верхняя панель
        header_frame = Frame(self.root, bg="#7B1FA2", height=80)
        header_frame.pack(fill=X)
        header_frame.pack_propagate(False)
        
        Label(header_frame, text="📚 Light English", font=("Arial", 18, "bold"), 
             bg="#7B1FA2", fg="#FFFFFF").pack(side=LEFT, padx=20)
        
        Button(header_frame, text="Выйти", command=self.quit_app, 
              bg="#AB47BC", fg="white", font=("Arial", 12), relief=FLAT, padx=20,
              activebackground="#9C27B0", activeforeground="white").pack(side=RIGHT, padx=20)
        
        # Основное содержимое
        content_frame = Frame(self.root, bg="#F3E5F5")
        content_frame.pack(expand=True, fill=BOTH, padx=20, pady=20)
        
        # Левая панель - категории
        left_frame = Frame(content_frame, bg="#F3E5F5", width=250)
        left_frame.pack(side=LEFT, fill=Y)
        
        # Список категорий
        categories_frame = Frame(left_frame, bg="#E1BEE7", padx=15, pady=15)
        categories_frame.pack(fill=BOTH, expand=True)
        
        Label(categories_frame, text="Категории", font=("Arial", 16, "bold"), 
             bg="#E1BEE7", fg="#7B1FA2").pack(anchor="w", pady=(0, 15))
        
        self.categories_listbox = Listbox(categories_frame, font=("Arial", 12), 
                                       bg="#F3E5F5", fg="#7B1FA2", selectbackground="#AB47BC",
                                       relief=FLAT, height=10)
        self.categories_listbox.pack(fill=BOTH, expand=True)
        self.categories_listbox.bind("<<ListboxSelect>>", self.on_category_select)
        
        # Кнопки управления категориями
        Button(left_frame, text="+ Добавить категорию", command=self.open_add_category,
              bg="#AB47BC", fg="white", font=("Arial", 12), relief=FLAT, padx=10, pady=8,
              activebackground="#9C27B0", activeforeground="white").pack(fill=X, pady=(10, 0))
        
        Button(left_frame, text="Просмотреть все слова", command=self.open_view_words,
              bg="#CE93D8", fg="#4A148C", font=("Arial", 12), relief=FLAT, padx=10, pady=8,
              activebackground="#BA68C8", activeforeground="#4A148C").pack(fill=X, pady=(10, 0))
        
        # Правая панель - слова
        right_frame = Frame(content_frame, bg="#F3E5F5", padx=20)
        right_frame.pack(side=RIGHT, fill=BOTH, expand=True)
        
        # Область изучения слов
        study_frame = Frame(right_frame, bg="#E1BEE7", padx=20, pady=20)
        study_frame.pack(fill=BOTH, expand=True)
        
        Label(study_frame, text="Изучение слов", font=("Arial", 16, "bold"), 
             bg="#E1BEE7", fg="#7B1FA2").pack(anchor="w", pady=(0, 20))
        
        self.word_label = Label(study_frame, text="Выберите категорию", font=("Arial", 24, "bold"), 
                              bg="#E1BEE7", fg="#6A1B9A")
        self.word_label.pack(pady=20)
        
        self.translation_label = Label(study_frame, text="", font=("Arial", 18), 
                                     bg="#E1BEE7", fg="#6A1B9A")
        self.translation_label.pack(pady=10)
        
        # Прогресс изучения
        self.progress_label = Label(study_frame, text="", font=("Arial", 10), 
                                  bg="#E1BEE7", fg="#6A1B9A")
        self.progress_label.pack()
        
        # Кнопки управления
        buttons_frame = Frame(study_frame, bg="#E1BEE7")
        buttons_frame.pack(pady=20)
        
        Button(buttons_frame, text="Показать перевод", command=self.show_translation, 
              bg="#7B1FA2", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#9C27B0", activeforeground="white").grid(row=0, column=0, padx=10)
        
        Button(buttons_frame, text="Следующее слово", command=self.next_word, 
              bg="#7B1FA2", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#9C27B0", activeforeground="white").grid(row=0, column=1, padx=10)
        
        # Добавление слов
        Button(right_frame, text="+ Добавить слово", command=self.open_add_word, 
              bg="#AB47BC", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#9C27B0", activeforeground="white").pack(fill=X, pady=(20, 0))
        
        # Статистика
        stats_frame = Frame(right_frame, bg="#E1BEE7", padx=20, pady=15)
        stats_frame.pack(fill=X, pady=(20, 0))
        
        Label(stats_frame, text="Статистика", font=("Arial", 12, "bold"), 
             bg="#E1BEE7", fg="#7B1FA2").pack(anchor="w", pady=(0, 10))
        
        self.total_words_label = Label(stats_frame, text="Всего слов: 0", 
                                    font=("Arial", 10), bg="#E1BEE7", fg="#6A1B9A")
        self.total_words_label.pack(anchor="w")
        
        self.categories_stats_label = Label(stats_frame, text="", 
                                         font=("Arial", 10), bg="#E1BEE7", fg="#6A1B9A")
        self.categories_stats_label.pack(anchor="w", pady=5)
        
        # Обновляем список категорий
        self.update_categories()

    def update_categories(self):
        """Обновляет список категорий"""
        categories = self.app.get_user_categories()
        self.categories_listbox.delete(0, END)
        for category in categories:
            self.categories_listbox.insert(END, category)
        
        if categories:
            self.categories_listbox.selection_set(0)
            self.on_category_select(None)

    def on_category_select(self, event):
        """Обработчик выбора категории"""
        selection = self.categories_listbox.curselection()
        if selection:
            self.current_category = self.categories_listbox.get(selection[0])
            self.load_words_for_category()
            self.next_word()

    def load_words_for_category(self):
        """Загружает все слова выбранной категории"""
        if self.current_category:
            words = self.app.get_all_words(self.current_category)
            self.word_list = list(words.items())
            shuffle(self.word_list)  # Перемешиваем слова
            self.current_index = 0

    def next_word(self):
        """Получает следующее слово из списка"""
        if not self.word_list:
            self.word_label.config(text="Нет слов в категории" if self.current_category else "Выберите категорию")
            self.translation_label.config(text="")
            self.progress_label.config(text="")
            return
            
        self.current_index = (self.current_index + 1) % len(self.word_list)
        self.current_word, self.current_translation = self.word_list[self.current_index]
        self.word_label.config(text=self.current_word)
        self.translation_label.config(text="")
        self.update_progress()

    def update_progress(self):
        """Обновляет информацию о прогрессе"""
        if self.word_list:
            progress_text = f"Слово {self.current_index + 1} из {len(self.word_list)}"
            self.progress_label.config(text=progress_text)

    def show_translation(self):
        """Показывает перевод слова"""
        if self.current_translation:
            self.translation_label.config(text=self.current_translation)

    def update_stats(self):
        """Обновляет статистику"""
        stats = self.app.get_words_count()
        self.total_words_label.config(text=f"Всего слов: {stats['total']}")
        
        categories_text = ""
        for cat, count in stats["categories"].items():
            categories_text += f"{cat}: {count} слов\n"
        
        self.categories_stats_label.config(text=categories_text.strip())
        
        # Обновляем статистику каждые 5 секунд
        self.root.after(5000, self.update_stats)

    def open_add_category(self):
        """Открывает окно добавления категории"""
        AddCategoryWindow(Toplevel(self.root), self.app, self.update_categories)

    def open_add_word(self):
        """Открывает окно добавления слова"""
        if self.current_category:
            AddWordWindow(Toplevel(self.root), self.app, self.current_category, self.update_categories)
        else:
            messagebox.showwarning("Ошибка", "Сначала выберите категорию")

    def open_view_words(self):
        """Открывает окно просмотра всех слов"""
        if self.current_category:
            ViewWordsWindow(Toplevel(self.root), self.app, self.current_category)
        else:
            messagebox.showwarning("Ошибка", "Сначала выберите категорию")

    def quit_app(self):
        self.root.quit()

class AddCategoryWindow:
    def __init__(self, root, app, callback):
        self.root = root
        self.app = app
        self.callback = callback
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title("Добавить категорию")
        self.root.geometry("400x300")
        self.root.resizable(False, False)
        self.root.configure(bg="#F3E5F5")
        center_window(self.root, 400, 300)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#F3E5F5", padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text="Добавить категорию", font=("Arial", 20, "bold"), 
             bg="#F3E5F5", fg="#7B1FA2").pack(fill=X, pady=(0, 30))
        
        form_frame = Frame(main_frame, bg="#F3E5F5")
        form_frame.pack(fill=X)
        
        Label(form_frame, text="Название категории:", bg="#F3E5F5", fg="#7B1FA2").pack(anchor="w")
        self.category_entry = Entry(form_frame, font=("Arial", 14), bg="#E1BEE7", fg="#4A148C", insertbackground="#4A148C", relief=FLAT)
        self.category_entry.pack(fill=X, ipady=8, pady=10)
        
        # Кнопки
        button_frame = Frame(main_frame, bg="#F3E5F5", pady=30)
        button_frame.pack(fill=X)
        
        Button(button_frame, text="Добавить", command=self.add_category,
              bg="#7B1FA2", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#9C27B0", activeforeground="white").pack(fill=X)
        
        Button(button_frame, text="Отмена", command=self.root.destroy,
              bg="#AB47BC", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#9C27B0", activeforeground="white").pack(fill=X, pady=(10, 0))

    def add_category(self):
        category = self.category_entry.get().strip()
        if not category:
            messagebox.showwarning("Ошибка", "Введите название категории")
            return
            
        if self.app.add_category(category):
            messagebox.showinfo("Успех", "Категория добавлена!")
            self.callback()
            self.root.destroy()
        else:
            messagebox.showerror("Ошибка", "Такая категория уже существует")

class AddWordWindow:
    def __init__(self, root, app, category, callback):
        self.root = root
        self.app = app
        self.category = category
        self.callback = callback
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title(f"Добавить слово в {self.category}")
        self.root.geometry("400x400")
        self.root.resizable(False, False)
        self.root.configure(bg="#F3E5F5")
        center_window(self.root, 400, 400)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#F3E5F5", padx=30, pady=30)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text=f"Добавить слово в {self.category}", 
             font=("Arial", 20, "bold"), bg="#F3E5F5", fg="#7B1FA2").pack(fill=X, pady=(0, 30))
        
        form_frame = Frame(main_frame, bg="#F3E5F5")
        form_frame.pack(fill=X)
        
        Label(form_frame, text="Английское слово:", bg="#F3E5F5", fg="#7B1FA2").pack(anchor="w")
        self.english_entry = Entry(form_frame, font=("Arial", 14), bg="#E1BEE7", fg="#4A148C", insertbackground="#4A148C", relief=FLAT)
        self.english_entry.pack(fill=X, ipady=8, pady=10)
        
        Label(form_frame, text="Русский перевод:", bg="#F3E5F5", fg="#7B1FA2").pack(anchor="w")
        self.russian_entry = Entry(form_frame, font=("Arial", 14), bg="#E1BEE7", fg="#4A148C", insertbackground="#4A148C", relief=FLAT)
        self.russian_entry.pack(fill=X, ipady=8, pady=10)
        
        # Кнопки
        button_frame = Frame(main_frame, bg="#F3E5F5", pady=30)
        button_frame.pack(fill=X)
        
        Button(button_frame, text="Добавить", command=self.add_word,
              bg="#7B1FA2", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#9C27B0", activeforeground="white").pack(fill=X)
        
        Button(button_frame, text="Отмена", command=self.root.destroy,
              bg="#AB47BC", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#9C27B0", activeforeground="white").pack(fill=X, pady=(10, 0))

    def add_word(self):
        english = self.english_entry.get().strip()
        russian = self.russian_entry.get().strip()
        
        if not english or not russian:
            messagebox.showwarning("Ошибка", "Заполните все поля")
            return
            
        if self.app.add_word(self.category, english, russian):
            messagebox.showinfo("Успех", "Слово добавлено!")
            self.callback()
            self.root.destroy()
        else:
            messagebox.showerror("Ошибка", "Не удалось добавить слово")

class ViewWordsWindow:
    def __init__(self, root, app, category):
        self.root = root
        self.app = app
        self.category = category
        self.setup_window()
        self.create_widgets()
        
    def setup_window(self):
        self.root.title(f"Слова в категории {self.category}")
        self.root.geometry("600x500")
        self.root.configure(bg="#F3E5F5")
        center_window(self.root, 600, 500)
        
    def create_widgets(self):
        main_frame = Frame(self.root, bg="#F3E5F5", padx=20, pady=20)
        main_frame.pack(expand=True, fill=BOTH)
        
        Label(main_frame, text=f"Слова в категории '{self.category}'", 
             font=("Arial", 18, "bold"), bg="#F3E5F5", fg="#7B1FA2").pack(pady=10)
        
        # Таблица слов
        tree_frame = Frame(main_frame, bg="#F3E5F5")
        tree_frame.pack(expand=True, fill=BOTH)
        
        self.tree = ttk.Treeview(tree_frame, columns=("english", "russian"), show="headings", height=15)
        self.tree.heading("english", text="Английское слово")
        self.tree.heading("russian", text="Русский перевод")
        self.tree.column("english", width=250)
        self.tree.column("russian", width=250)
        
        style = ttk.Style()
        style.configure("Treeview", background="#F3E5F5", fieldbackground="#F3E5F5", foreground="#4A148C")
        style.configure("Treeview.Heading", background="#E1BEE7", foreground="#7B1FA2")
        
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill=Y)
        
        # Заполняем таблицу
        words = self.app.get_all_words(self.category)
        for english, russian in words.items():
            self.tree.insert("", "end", values=(english, russian))
        
        # Кнопка закрытия
        Button(main_frame, text="Закрыть", command=self.root.destroy,
              bg="#AB47BC", fg="white", font=("Arial", 12), relief=FLAT, padx=20, pady=10,
              activebackground="#9C27B0", activeforeground="white").pack(pady=20)

def center_window(root, width, height):
    """Центрирует окно на экране"""
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2 - 50
    root.geometry(f"{width}x{height}+{x}+{y}")

def main():
    app = EnglishWords()
    root = Tk()
    AuthWindow(root, app)
    root.mainloop()

if __name__ == "__main__":
    main()